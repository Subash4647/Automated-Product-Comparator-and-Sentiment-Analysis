import express from 'express';
import 'dotenv/config';
import cors  from 'cors';
import connectDB from './config/db.js';
import authRoutes from "./routes/auth.js";


// App Config
const app  = express();
const port = process.env.PORT  || 4000


// Middleware
app.use(express.json()) // Parsed
app.use(cors()) 
connectDB();

// api endpoints



// ZFBiCiTDR4Dr6hfQ;
// stalinkumanan;

app.use("/api/auth", authRoutes);

app.get('/',(req,res)=>{
     res.send('API WORKING');
})



app.listen(port,(req,res)=>{
    console.log(`http://localhost:${port}`);
})
