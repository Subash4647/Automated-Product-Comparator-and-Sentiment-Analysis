import Review from "../models/Review.js";

export const reviewpost = async (req, res) => {
    try {
      const { reviewername, revieweremail, review } = req.body;
  
      const newReview = new Review({ reviewername, revieweremail, review });
      const saved = await newReview.save();
  
      res.status(201).json(saved);
    } catch (error) {
      res.status(400).json({ error: error.message });
    }
  };


  export const getAllReviews = async (req, res) => {
    try {
      const reviews = await Review.find().sort({ createdAt: -1 });
      res.json(reviews);
    } catch (error) {
      res.status(500).json({ message: "Error fetching reviews", error });
    }
  };