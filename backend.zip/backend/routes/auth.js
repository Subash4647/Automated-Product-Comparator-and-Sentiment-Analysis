import express from "express";
import { signup, login, adminLogin, getUserById } from "../controllers/authController.js";
import { getAllReviews, reviewpost } from "../controllers/reviewController.js";

const router = express.Router();

router.post("/signup", signup);
router.post("/login", login);
router.post("/admin/login", adminLogin);
router.post("/user/:id", getUserById);
router.post("/reviewpost",reviewpost)
router.get("/getreview",getAllReviews)
export default router;
