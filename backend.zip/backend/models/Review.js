import mongoose from "mongoose";

const reviewSchema = new mongoose.Schema({
  reviewername: { type: String, required: true },
  review: { type: String, required: true },
}, { timestamps: true }); // This adds createdAt and updatedAt

const Review = mongoose.model("Review", reviewSchema);

export default Review;
