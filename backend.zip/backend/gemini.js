import axios  from "axios";

const API_KEY = "AIzaSyBzVCXPGmpJEKKZk3yz6bdkDBY0nyvl1Xo";

const url = `https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent?key=${API_KEY}`;

const data = {
  contents: [
    {
      parts: [{ text: "Web developer means" }],
    },
  ],
};

axios
  .post(url, data, {
    headers: {
      "Content-Type": "application/json",
    },
  })
  .then((response) => {
    const text = response.data.candidates?.[0]?.content?.parts?.[0]?.text;
    console.log("Gemini says:", text);
  })
  .catch((error) => {
    console.error("Error from Gemini:", error.response?.data || error.message);
  });
